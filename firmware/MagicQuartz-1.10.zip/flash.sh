#!/bin/bash

# This script tries to automatically flash the MagicQuartz firmware using a Linux machine. Use at your own risk!

# The file to be uploaded:
HEXFILE=MagicQuartz-1.10.hex

# Try to detect the USB device:
NUMPORTS=0
if [ -e "/dev/ttyUSB0" ]; then
	echo "Found Arduino-like development board at /dev/ttyUSB0 ..."
	DEVICE=/dev/ttyUSB0
	NUMPORTS=$((NUMPORTS + 1))
fi
if [ -e "/dev/ttyUSB1" ]; then
	echo "Found Arduino-like development board at /dev/ttyUSB1 ..."
	DEVICE=/dev/ttyUSB1
	NUMPORTS=$((NUMPORTS + 1))
fi
if [ -e "/dev/ttyACM0" ]; then
	echo "Found original Arduino development board at /dev/ttyACM0 ..."
	DEVICE=/dev/ttyACM0
	NUMPORTS=$((NUMPORTS + 1))
fi
if [ -e "/dev/ttyACM1" ]; then
	echo "Found original Arduino development board at /dev/ttyACM1 ..."
	DEVICE=/dev/ttyACM1
	NUMPORTS=$((NUMPORTS + 1))
fi

# If a device was found, try to flash the file:
if [ "$NUMPORTS" -eq "1" ]; then
	if [ -e "/usr/bin/avrdude" ]; then
		/usr/bin/avrdude -C/etc/avrdude.conf -v -patmega2560 -cwiring -P$DEVICE -b115200 -D -Uflash:w:$HEXFILE:i -U hfuse:r:-:h -U lfuse:r:-:h -U efuse:r:-:h
	else
		echo "ERROR: The tool 'avrdude' is not installed. Aborting ..."
	fi
else
	echo "ERROR: Expected one development board, but found $NUMPORTS. Aborting ..."
fi
